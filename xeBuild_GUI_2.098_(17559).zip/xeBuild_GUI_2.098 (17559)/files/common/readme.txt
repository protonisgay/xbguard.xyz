Bootloader files that are common to all build versions can be placed here
instead of copied separately to each directory.
